/* Q3 extras: register trace, popcount, precedence, signedness, array alternative */
#include <stdio.h>
#include <time.h>
#include <string.h>

enum { LIGHT = 0, FAN = 1, AC = 2, HEATER = 3, PUMP = 4 };
static unsigned char switch_on(unsigned char r, int d)  { return (unsigned char)(r | (1u << d)); }
static unsigned char switch_off(unsigned char r, int d) { return (unsigned char)(r & ~(1u << d)); }
static unsigned char toggle(unsigned char r, int d)     { return (unsigned char)(r ^ (1u << d)); }
static int is_on(unsigned char r, int d)                { return (r >> d) & 1u; }
static void show(unsigned char r) { for (int b = 7; b >= 0; b--) putchar(((r >> b) & 1u) ? '1' : '0'); }

static int count_on_loop(unsigned char r) { int c = 0; for (int b = 0; b < 8; b++) c += (r >> b) & 1u; return c; }
static int count_on_kernighan(unsigned char r, int *steps) { int c = 0; *steps = 0; while (r) { r &= (unsigned char)(r - 1); c++; (*steps)++; } return c; }

int main(void)
{
    /* Designed sequence with predictions (written before running):
       start 00000000
       on LIGHT -> 00000001, on FAN -> 00000011, on PUMP -> 00010011,
       toggle AC -> 00010111, off FAN -> 00010101, toggle LIGHT -> 00010100,
       toggle HEATER -> 00011100, on bit7 style value via reg|0x80 -> 10011100   */
    const char *pred[] = {"00000001","00000011","00010011","00010111","00010101","00010100","00011100"};
    unsigned char reg = 0;
    printf("Register trace (predicted vs observed)\n");
    struct { const char *txt; int op; int dev; } seq[] = {
        {"on LIGHT", 0, LIGHT}, {"on FAN", 0, FAN}, {"on PUMP", 0, PUMP}, {"toggle AC", 2, AC},
        {"off FAN", 1, FAN}, {"toggle LIGHT", 2, LIGHT}, {"toggle HEATER", 2, HEATER}};
    for (int i = 0; i < 7; i++) {
        reg = seq[i].op == 0 ? switch_on(reg, seq[i].dev) :
              seq[i].op == 1 ? switch_off(reg, seq[i].dev) : toggle(reg, seq[i].dev);
        char buf[9]; for (int b = 7; b >= 0; b--) buf[7 - b] = ((reg >> b) & 1u) ? '1' : '0'; buf[8] = 0;
        printf("  %-14s predicted %s observed %s  %s  (0x%02X)\n", seq[i].txt, pred[i], buf,
               strcmp(pred[i], buf) == 0 ? "OK" : "MISMATCH", reg);
    }
    int steps;
    int k_count = count_on_kernighan(reg, &steps);
    printf("Devices ON (loop)=%d, (Kernighan)=%d in %d iterations\n", count_on_loop(reg), k_count, steps);
    printf("is_on checks: LIGHT=%d FAN=%d AC=%d HEATER=%d PUMP=%d\n",
           is_on(reg, LIGHT), is_on(reg, FAN), is_on(reg, AC), is_on(reg, HEATER), is_on(reg, PUMP));

    /* Precedence: reg & 1 << dev  ==  reg & (1 << dev)  (shift binds tighter than &)
                   (reg & 1) << dev  tests only bit 0 and then shifts */
    unsigned char r = 0x14; int dev = 2;  /* 00010100: bit 2 set, bit 0 clear */
    printf("\nreg=0x14 dev=2: reg & 1 << dev = %d (tests bit 2: correct, value 4)\n", r & 1 << dev);
    printf("                (reg & 1) << dev = %d (tests bit 0, then shifts: wrong)\n", (r & 1) << dev);
    r = 0x15; /* bit 0 set */
    printf("reg=0x15 dev=2: reg & 1 << dev = %d, (reg & 1) << dev = %d (reports 4 for bit 0, not bit 2)\n", r & 1 << dev, (r & 1) << dev);

    /* Signedness: bit 7 set in signed char */
    signed char sc = (signed char)0x80;  /* implementation-defined conversion, -128 on gcc */
    unsigned char uc = 0x80;
    printf("\nsigned char 0x80 = %d, >>7 gives %d (arithmetic shift, sign extension); unsigned char 0x80 >>7 gives %d\n",
           sc, sc >> 7, uc >> 7);
    printf("sc >> 7 & 1 = %d (ok after masking), but printing (sc >> 4) = %d, 0x%X (sign-extended)\n", (sc >> 7) & 1, sc >> 4, (unsigned)(sc >> 4));
    printf("sc == 0x80 is %s (promotes to -128 vs 128); uc == 0x80 is %s\n", sc == 0x80 ? "true" : "false", uc == 0x80 ? "true" : "false");
    printf("~sc & 0xFF = 0x%X; ~uc = 0x%X (int promotion: mask result)\n", ~sc & 0xFF, ~uc);

    /* Alternative: char state[8] */
    char st[8] = {0};
    st[LIGHT] = 1; st[AC] = 1; st[FAN] ^= 1; st[LIGHT] = 0;
    printf("\nArray version after same main() steps: ");
    for (int i = 7; i >= 0; i--) putchar('0' + st[i]);
    int cnt = 0, iters = 0; for (int i = 0; i < 8; i++) { cnt += st[i]; iters++; }
    printf("  count ON=%d in %d iterations\n", cnt, iters);

    printf("Space for 1,000,000 homes: bitfield = %zu bytes, array = %zu bytes\n",
           (size_t)1000000 * sizeof(unsigned char), (size_t)1000000 * sizeof(st));

    /* Timing: count ON devices over 1e6 homes */
    enum { H = 1000000 };
    static unsigned char regs[H]; static char arr[H][8];
    for (int i = 0; i < H; i++) { regs[i] = (unsigned char)((i * 37u) & 0xFF); for (int b = 0; b < 8; b++) arr[i][b] = (regs[i] >> b) & 1; }
    long tot1 = 0, tot2 = 0, it1 = 0, it2 = 0;
    clock_t t0 = clock();
    for (int i = 0; i < H; i++) { int s; tot1 += count_on_kernighan(regs[i], &s); it1 += s; }
    clock_t t1 = clock();
    for (int i = 0; i < H; i++) for (int b = 0; b < 8; b++) { tot2 += arr[i][b]; it2++; }
    clock_t t2 = clock();
    printf("Counting ON devices for 1e6 homes: bit/Kernighan total=%ld iterations=%ld time=%.1f ms; array total=%ld iterations=%ld time=%.1f ms\n",
           tot1, it1, 1000.0 * (t1 - t0) / CLOCKS_PER_SEC, tot2, it2, 1000.0 * (t2 - t1) / CLOCKS_PER_SEC);
    (void)show;
    return 0;
}
