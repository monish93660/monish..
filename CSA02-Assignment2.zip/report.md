# C Programming – Assignment 2 (CO2) Report

**Name:** `<YOUR NAME>`  **Register No.:** `<YOUR REGISTER NUMBER>`
**GitHub repository:** `<https://github.com/<user>/CSA02-<RegisterNumber>-Assignment2>`
**Compiler:** gcc 13.3.0, flags `-Wall -Wextra`. All counts below are real measurements copied from the `output*.txt` files in each folder.

---

## Q1 – Precedence, Associativity and the Discount Bug

### Code under test
```c
total = price * qty - price * qty * 15 / 100 * senior + price * qty * 5 / 100;
net   = total > 1000 ? total - 50 : total;
count = count++ + 1;
```

### Operator order (precedence and associativity)
`*` and `/` have higher precedence than `+` and `-`, and associate left to right. Order for the total expression:

1. `price*qty` (term 1)
2. `price*qty` → `*15` → `/100` → `*senior` (term 2; strictly left to right, so division happens BEFORE multiplying by `senior`)
3. `price*qty` → `*5` → `/100` (term 3)
4. term1 − term2, then + term3 (left to right)
5. `=` last (right-to-left, lowest precedence).

For `net`: `>` binds tighter than `?:`, `?:` binds tighter than `=`; `?:` is right-associative.

### Predictions (made before running) and observations

| Bill | price | qty | senior | Predicted total | Observed total | Predicted net | Observed net | Intended (correct) |
|---|---|---|---|---|---|---|---|---|
| 1 | 250 | 4 | 1 | 1000 − (15000/100=150) + (5000/100=50) = **900** | 900 | 900 | 900 | 892.50 |
| 2 | 99 | 3 | 1 | 297 − (4455/100=44) + (1485/100=14) = **267** | 267 | 267 | 267 | 265.0725 |
| 3 | 1200 | 1 | 0 | 1200 − 0 + 60 = **1260** | 1260 | 1260 − 50 = **1210** | 1210 | 1210 |

### Which expressions differ from the pharmacist's intent
1. **Logic error (not precedence):** GST (5%) is computed on the *gross* amount, not on the discounted amount. Bill 1: 900 instead of 892.50.
2. **Integer division:** `297*15/100` = 44 (true 44.55) and `297*5/100` = 14 (true 14.85); paise are lost. Bill 2 is 267 instead of 265.0725. Also `15/100*297` evaluates to 0, which shows how the order of operands matters in integer arithmetic.
3. Bill 3 is correct only by coincidence (no discount, and 5% of 1200 is exact).
4. `net`: 50 off is applied on the post-GST total; confirm this with the pharmacist. The ternary itself is correct.

### Inquiry – why `count = count++ + 1` is undefined
`count` is modified twice (by `++` and by `=`) between two sequence points, with no ordering defined by the language. The compiler may store the incremented value, the `+1` value, or anything else. gcc -Wall reports:
`warning: operation on 'count' may be undefined [-Wsequence-point]` (`Q1/compile_warnings.txt`). With count=5 gcc gave 6 here, but this is not guaranteed on other compilers or optimisation levels.

### Design decision – corrected calculation
```c
gross    = price * qty;
discount = senior ? gross * 0.15 : 0.0;
taxable  = gross - discount;
gst      = taxable * 0.05;
total    = taxable + gst;
net      = total > 1000.0 ? total - 50.0 : total;
```
Intermediate variables were chosen (brackets alone would still leave one unreadable line and still repeat `price*qty`). `double` removes truncation; in a real billing system integer paise would be preferred to avoid binary floating-point error.

### Alternative concept – intermediate variables
| | Single expression | Intermediate variables |
|---|---|---|
| Arithmetic operations | 8 mul/div + 2 add/sub = 10 | 5 (price*qty computed once) |
| Extra space | 0 | 5 doubles (40 bytes), O(1) |
| Time complexity | O(1) | O(1) |
| Correctness / readability | easy to get wrong; wrong tax base | each step named and testable |

An optimising compiler may remove the repeated `price*qty` anyway, so the real benefit is correctness and readability, not speed.

---

## Q2 – Short-Circuit Evaluation

### Experiments (observed, `Q2/output.txt`)
| Expression | Second operand evaluated? |
|---|---|
| `0 && f()` | NO |
| `1 && f()` | YES |
| `1 || f()` | NO |
| `0 || f()` | YES |
| `0 & f()` | YES (`&` always evaluates both) |
| `1 | f()` | YES |

`(0 && x++)` leaves x = 0; `(0 & x++)` makes x = 1. Also `2 && 1` = 1 but `2 & 1` = 0, so `&` is not a drop-in replacement for `&&` on non-0/1 values.

### Call counts: 1000 passengers (305 seniors, 416 eligible class, 102 disability card; fixed LCG seed)
| Version | Slow-function calls (no audit) | Audit entries (audit on) |
|---|---|---|
| A: `(S && E) \|\| slow()` | **875** | 875 |
| B: `slow() \|\| (S && E)` | 1000 | 1000 |
| C: `(S & E) \| slow()` | 1000 | 1000 |
| D: nested if | **875** | 875 |

875 = 1000 − 125, where 125 passengers satisfy S && E, so the OR short-circuits before the slow call.

### Order of conditions
- For `A || B`, put the condition that is **cheap and most likely TRUE** first; for `A && B`, put the cheap condition that is **most likely FALSE** first. Here, putting the cheap `(S&&E)` first saved 12.5% of the slow calls. Putting `slow()` first would save only when the card is held (10.2%), but you pay for the call every time.
- Order is irrelevant when both operands are equally cheap, have no side effects, and probabilities are similar, or when the result of the first never decides the outcome.

### Changed condition – audit log
If every passenger must be logged, short-circuiting is now a **bug**: version A/D log only 875 of 1000 passengers. The verification (with its logging) must be executed unconditionally, e.g. `int card = slow_verify(...); if ((S && E) || card)`, giving 1000 calls and 1000 log entries in any order. Better still: separate logging from verification so the audit does not depend on evaluation order. The recommended order from the unaudited case no longer applies.

### Alternative concept – nested if, or `&`/`|`
- Nested `if`: behaves exactly like `&&`/`||`; slow calls = n(1 − p) where p = P(S∧E) (875 measured).
- `&`/`|`: slow function is called for all n passengers: exactly n calls (1000 measured).
- Time: both O(n) worst case; short-circuit reduces only the constant (measured 875 vs 1000). Space: O(1) for all.

---

## Q3 – Device-Status Register with Bitwise Operators

### Complete the code (TODO 1–4, `Q3/q3_complete.c`)
```c
switch_on : return (unsigned char)(reg |  (1u << dev));
switch_off: return (unsigned char)(reg & ~(1u << dev));
toggle    : return (unsigned char)(reg ^  (1u << dev));
is_on     : return (reg >> dev) & 1u;
```
Logic: `1u << dev` builds a mask with only bit `dev` set. OR sets it, AND with the complement clears it, XOR flips it, and shifting right then masking with 1 reads it.

**Register after each statement of the given `main()` (predicted, then verified):**

| Statement | Register |
|---|---|
| `reg = 0` | 00000000 |
| `switch_on(LIGHT)` | 00000001 |
| `switch_on(AC)` | 00000101 ← printed |
| `toggle(FAN)` | 00000111 |
| `switch_off(LIGHT)` | 00000110 ← printed |

Output: `00000101`, `00000110`, `AC is ON, PUMP is OFF`, which matches the expected output.

### Own designed sequence (prediction vs observation, `Q3/output_extra.txt`)
on LIGHT 00000001 → on FAN 00000011 → on PUMP 00010011 → toggle AC 00010111 → off FAN 00010101 → toggle LIGHT 00010100 → toggle HEATER 00011100. All 7 predictions matched. Devices on = 3 (loop count and Kernighan's `r &= r-1`, 3 iterations).

### Inquiry
- `reg & 1 << dev` parses as `reg & (1 << dev)` because `<<` has higher precedence than `&`, so it tests bit `dev`. `(reg & 1) << dev` tests only bit 0 and then shifts the answer. With reg = 0x14, dev = 2: first gives 4 (correct), second gives 0. With reg = 0x15 (bit 0 set, bit 2 clear): second gives 4 even though bit 2 is not tested.
- With a **signed char** and bit 7 set (0x80) the value is −128. `>>` on a negative value is implementation-defined (gcc: arithmetic shift, sign extension): `sc >> 7` = −1, `sc >> 4` = −8 (0xFFFFFFF8 as int), whereas for unsigned char `>> 7` = 1. Also `sc == 0x80` is false (−128 vs 128). `~` promotes to int, so results need masking with `0xFF`. Hence `unsigned char` is correct for a bit register.

### Alternative – `char state[8]`
| | Bit register | Array |
|---|---|---|
| set / clear / toggle / test | O(1) | O(1) |
| Count ON devices | O(k) with Kernighan (k = devices ON) or O(8) | O(8) |
| Space per home | 1 byte | 8 bytes |
| Space, 1,000,000 homes | **1,000,000 bytes** | **8,000,000 bytes** |

Measured count over 1e6 homes: bit/Kernighan 3,999,996 iterations, 8.6 ms; array 8,000,000 iterations, 19.9 ms (timings vary by machine). Trade-off: array is simpler to read and index; bits are 8× smaller and can be copied/compared/saved as one byte but need care with precedence and signedness.

---

## Q4 – else-if Ladder or switch

### Complete the code (TODO 1)
```c
switch (marks / 10) {
case 10:
case 9:  return 'S';
case 8:  return 'A';
case 7:  return 'B';
case 6:  return 'C';
case 5:  return 'D';
default: return 'F';
}
```
Cases 10 and 9 are combined (100 and 90–99 are both S); `default` covers 0–49. Output: `100:S 95:S 83:A 50:D 49:F -5:?` (matches expected).

### Test results (`Q4/output_compare.txt`)
| marks | ladder | switch | table | switch without break |
|---|---|---|---|---|
| 100 | S | S | S | S |
| 90 | S | S | S | S |
| 89 | A | A | A | **B** |
| 80 | A | A | A | **B** |
| 79 / 70 | B | B | B | B |
| 69 / 60 | C | C | C | C |
| 59 / 50 | D | D | D | D |
| 49 / 0 | F | F | F | F |
| −1 / 101 | ? | ? | ? | ? |

Exhaustive check −5..105 (111 values): ladder, switch and table disagree **0** times.

### Missing break
Removing the `return`/`break` after case 8 lets execution fall into case 7: all marks 80–89 become **B** (10 wrong values out of 111).

### Questions
- **Why can switch not test 75–84?** Each `case` label must be a single integer constant; a range is not allowed in standard C (the `case 75 ... 84` form is a non-portable gcc extension). Also `marks/10` merges 70–79 into one case, so 75–84 straddles two cases.
- **Why the range check comes first:** in C, `-5 / 10` is 0 (truncation toward zero), so without the check −9..−1 would be graded F. 
- **Easiest to change when boundaries change:** the lookup table or the ladder (one number to edit). The `marks/10` switch silently assumes boundaries are multiples of 10, so a boundary such as 75 forces a redesign.

### Boundary-exposing test set
For every boundary b ∈ {0, 50, 60, 70, 80, 90, 100}: test b−1, b, b+1; plus −1, 101, and extremes (INT_MIN, INT_MAX) for the range guard.

### Design decision – scholarship (grade × income)
A **2-D lookup table** `scholarship[grade][income band]` is the best structure: the rule is data, not logic, so changing amounts needs no code change, every cell is visible and testable, and lookup is O(1). Nested if grows quickly (5 × 4 branches), and switch-inside-if still needs a second decision per grade. Implemented in `q4_compare.c` and printed as a table.

### Alternative – lookup table
Table `char grades[11]` indexed by `marks/10`: O(1) time, 11 bytes of space. The ladder took 502 comparisons for marks 0..100 (4.97 on average, maximum 6); switch uses one jump-table index (O(1) when the compiler generates a jump table) and table lookup is a single index. Table is the shortest and easiest to modify, but it has the same multiple-of-10 limitation as the switch.

---

## Q5 – Counting the Work Done by a Loop

### Deriving the loop condition
If n = a·b with a ≤ b, then a² ≤ a·b = n, so the smaller divisor satisfies a ≤ √n. Hence only divisors i with **`i * i <= n`** need testing (no `sqrt()` call). Stop with `return 0` at the first divisor; counting `checks++` before each `%`.

### Complete the code (`Q5/q5_complete.c`)
```c
for (unsigned long i = 2; i * i <= n; i++) {
    checks++;
    if (n % i == 0) return 0;
}
return 1;
```
Output matches expected exactly: 97 → 8, 100 → 1, 7919 → 87, 1000003 → 999.

### Division counts (all versions, `Q5/output_versions.txt`)
| n | result | `i < n` (for) | `i*i <= n` for | while | do-while |
|---|---|---|---|---|---|
| 2 | prime | 0 | 0 | 0 | 0 |
| 3 | prime | 1 | 0 | 0 | 0 |
| 4 | not prime | 1 | 1 | 1 | 1 |
| 97 | prime | 95 | 8 | 8 | 8 |
| 100 | not prime | 1 | 1 | 1 | 1 |
| 7919 | prime | 7917 | 87 | 87 | 87 |
| 1000003 | prime | 1000001 | 999 | 999 | 999 |
| 999983 | prime | 999981 | 998 | 998 | 998 |
| 1000001 (= 101 × 9901) | not prime | 100 | 100 | 100 | 100 |

### Inquiry
- **do-while for n = 2 and 3:** a do-while executes the body once before checking the condition. For n = 2, the first pass tests `2 % 2 == 0` and wrongly reports "not prime" (observed). For n = 3 the result is correct but one unnecessary division is done (3 % 2). So the do-while version needs a guard (`if (n < 4) return 1;`) *before* the loop.
- **Overflow of `i * i <= n`:** with 32-bit unsigned, n = 4294967291 (prime), `i*i` wraps to 0 when i = 65536, so the condition stays true and the loop never ends correctly (stopped by the safety limit in the experiment). Fix: write `i <= n / i`, which does not multiply (verified: reports prime correctly). With 64-bit `unsigned long` the same problem arises for n near 2^64.

### Alternative – Sieve of Eratosthenes (N = 1,000,003)
| | Trial division (√n) | Sieve |
|---|---|---|
| Time | O(√n) per query | O(N log log N) once (2,122,051 marking operations measured, 4.9 ms), then O(1) per query |
| Space | O(1) | O(N): 1,000,004 bytes |
| Divisions | 999 for the large prime | 0 |

Trial division of every n from 2 to 1,000,003: **67,741,504 divisions** in total. Sieve found 78,499 primes. Sieve is better for many queries over a known range; trial division is better for one-off or very large n.

---

## Q6 – Loan Repayment Schedule

### Design
- **Loop choice: `while`.** The number of months is unknown in advance, and if the principal is already 0 the body must run zero times, which `do-while` cannot do. `for` fits only if the count is known.
- **Termination:** `while (balance > 0.005)`. `balance != 0` is dangerous because floating-point values rarely land exactly on 0: with repayments subtracted but no final-month adjustment, the balance went to −1354.62 and never equalled 0; repeated addition of 0.1 never hits 1.0 exactly (`b = 2.1000000000000005` after 20 steps).
- **Last month:** `payment = (balance < pay) ? balance : pay;` so the last instalment pays only what remains.
- **Repayment ≤ interest:** the balance never falls. The program rejects this before the loop (`pay <= principal * rate`).

### Hand-verified schedule: Rs 10,000, 2% per month, Rs 2,000 repayment (program output equals hand calculation)
| Month | Opening | Interest (2%) | Payment | Closing |
|---|---|---|---|---|
| 1 | 10000.00 | 200.00 | 2000.00 | 8200.00 |
| 2 | 8200.00 | 164.00 | 2000.00 | 6364.00 |
| 3 | 6364.00 | 127.28 | 2000.00 | 4491.28 |
| 4 | 4491.28 | 89.83 | 2000.00 | 2581.11 |
| 5 | 2581.11 | 51.62 | 2000.00 | 632.73 |
| 6 | 632.73 | 12.65 | 645.38 | 0.00 |

**6 months, total interest Rs 645.38, total paid Rs 10,645.38.**

### Growth investigation (P = 10,000; monthly interest = 200)
| Repayment | Months (simulated) | Closed form n | Total interest |
|---|---|---|---|
| 5000 | 3 | 2.06 | 310.08 |
| 3000 | 4 | 3.48 | 459.50 |
| 2000 | 6 | 5.32 | 645.38 |
| 1000 | 12 | 11.27 | 1270.33 |
| 500 | 26 | 25.80 | 2898.73 |
| 300 | 56 | 55.48 | 6644.17 |
| 250 | 82 | 81.27 | 10318.98 |
| 220 | 122 | 121.09 | 16639.92 |
| 210 | 154 | 153.74 | 22286.50 |
| 205 | 188 | 187.53 | 28444.00 |
| 201 | 268 | 267.81 | 43829.75 |
| 200.01 | > 360 (limit hit) | 500.11 | – |
| 200 / 150 | rejected | – | – |

Prediction: months grow slowly while the repayment is well above the interest, then explode as repayment → 200, because n = −ln(1 − rP/E)/ln(1+r) → ∞ as E → rP. The measurements confirm this (201 → 268 months, 200.01 → over 360).

### Deployment decision
Safety limit = 360 months (30 years) via `break`/return; the message when reached: *"Loan not repayable within 360 months at this instalment; increase repayment."* A hard failure message is better than printing a schedule that goes on forever, and the up-front check `repayment <= interest` gives a more precise message in the impossible case.

### Alternative – closed formula
n = −ln(1 − rP/E) / ln(1 + r) → 5.32, so ceil = **6** (matches the simulation).
| | Simulation loop | Formula |
|---|---|---|
| Time | O(n) iterations (6 here, up to 360) | O(1) |
| Space | O(1) (O(n) if schedule stored) | O(1) |
| Gives monthly schedule? | yes | no, only the count (not the last payment unless recomputed) |
| Precision | small rounding accumulation each month | argument 1 − rP/E → 0 near E = rP (loss of precision); NaN/invalid if E ≤ rP so it must be tested first |

Use the formula for a quick feasibility estimate, and the loop for the actual schedule.

---

## Q7 – Day-4 Design Challenge: Redesign of Q5 (prime verification)

### A. Diagnose the bottleneck (evidence from Q5)
- Operations are all `%` divisions in the loop; the count grows as √n: 999 for 1000003, 87 for 7919, 8 for 97.
- Verifying every ticket 2..1,000,003 costs **67,741,504 divisions**.
- Work is wasted in two ways: (1) after testing 2, every other even divisor is useless, and after 3 so are multiples of 3, so only 1/3 of the tested divisors can ever succeed; (2) divisibility information is recomputed for each ticket, although the tickets share the same small primes.

### B. Objective
(1) Cut divisions for large prime tickets by at least 60% without extra memory (target ≤ 400 for 1,000,003); (2) for the batch workload, remove per-ticket divisions altogether.

### C. Redesign
**Redesign 1 – 6k ± 1 wheel:** every prime above 3 has the form 6k ± 1, so test 2, 3, and then 5, 7, 11, 13, 17, 19, … (step 6, two tests per step). No extra memory.

```
function is_prime(n):
    if n < 2: return 0
    if n < 4: return 1
    if n mod 2 == 0 or n mod 3 == 0: return 0
    i = 5
    while i*i <= n:
        if n mod i == 0 or n mod (i+2) == 0: return 0
        i = i + 6
    return 1
```
```
 [start] -> n<2? --yes--> 0
            n<4? --yes--> 1
            n%2==0 or n%3==0? --yes--> 0
            i=5 -> i*i<=n? --no--> 1
                    n%i==0 or n%(i+2)==0? --yes--> 0
                    i+=6 -> (back to i*i<=n)
```
**Redesign 2 – Sieve of Eratosthenes** (batch): mark composites once, then answer each ticket by array lookup. Costs N+1 bytes and a one-time build.

### D. Prediction (made before implementation)
Redesign 1: only about 1/3 of the original divisor candidates remain, so ≈ √n/3 ≈ 333 + 2 divisions for 1,000,003 (a ~66% reduction) and about 65% fewer divisions over all tickets. Redesign 2: ≈ N·ln ln N ≈ 2–3 million marking operations in total, about 30× fewer than 67.7 million divisions, with 1 MB of memory.

### E. Implementation and measurements (same inputs, `Q7/output.txt`)
| n | original | 6k±1 | saved | sieve |
|---|---|---|---|---|
| 97 | 8 | 4 | 50.0% | 0 |
| 100 | 1 | 1 | 0% | 0 |
| 7919 | 87 | 30 | 65.5% | 0 |
| 1000003 | 999 | 334 | 66.6% | 0 |
| 999983 | 998 | 334 | 66.5% | 0 |
| 1000001 | 100 | 35 | 65.0% | 0 |

Batch of every ticket 1..1,000,003:
| Method | Divisions | Time | Extra memory |
|---|---|---|---|
| Original | 67,741,504 | 180.1 ms | 0 |
| 6k±1 | 23,739,568 (−65.0%) | 58.6 ms | 0 |
| Sieve | 0 (2,122,051 marks) | 5.0 ms build + 1.7 ms lookups | 1,000,004 bytes |

The wheel and sieve agree on all 78,499 primes (0 disagreements).

Few-query break-even (large n near 1,000,003): 1 query: original 999, wheel 334 vs sieve 2,122,051 marks; 10,000 queries: original 1,872,978, wheel 640,850, sieve 2,122,051 marks.

### F. Defence of the final design
- **Objective met:** 66.6% fewer divisions for the large prime (334 ≤ 400) and 65.0% fewer over the batch, matching the 66%/65% prediction. For batch verification the sieve removes the divisions entirely (about 32× fewer basic operations, about 27× faster in the measured run).
- **Costs:** the wheel adds slightly more complex code and the special-case guards for 2 and 3; the sieve needs O(N) memory (1 MB here) and a known upper bound.
- **When the original is still preferable:** a single or very few queries (the sieve's 2.1 million marks versus 334 divisions per wheel query), very large n beyond the memory limit, or when simple code matters more than speed. The 6k±1 wheel does not improve the O(√n) complexity, only the constant factor.
- **Final recommendation:** use the sieve for verifying all tickets up to 1,000,003 (organisers' use case), and the 6k±1 test for isolated checks. Timings are single-run measurements and vary by machine; operation counts are the primary evidence.

---

## Appendix – How to reproduce
See `README.md` for compile/run commands; all raw outputs are in each `Qn/output*.txt`.
