/* Q5: all loop versions, division counts, boundary cases, overflow, sieve */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

unsigned long checks = 0;

static int prime_full_for(unsigned long n)          /* divisors 2 .. n-1 */
{
    checks = 0; if (n < 2) return 0;
    for (unsigned long i = 2; i < n; i++) { checks++; if (n % i == 0) return 0; }
    return 1;
}
static int prime_sqrt_for(unsigned long n)
{
    checks = 0; if (n < 2) return 0;
    for (unsigned long i = 2; i * i <= n; i++) { checks++; if (n % i == 0) return 0; }
    return 1;
}
static int prime_sqrt_while(unsigned long n)
{
    checks = 0; if (n < 2) return 0;
    unsigned long i = 2;
    while (i * i <= n) { checks++; if (n % i == 0) return 0; i++; }
    return 1;
}
/* Correct do-while: the guard for n < 4 must come BEFORE the loop */
static int prime_sqrt_dowhile(unsigned long n)
{
    checks = 0; if (n < 2) return 0;
    if (n < 4) return 1;                 /* 2 and 3: loop body would test 2 % 2 */
    unsigned long i = 2;
    do { checks++; if (n % i == 0) return 0; i++; } while (i * i <= n);
    return 1;
}
/* Naive do-while without the guard (shows the bug) */
static int prime_dowhile_naive(unsigned long n)
{
    checks = 0; if (n < 2) return 0;
    unsigned long i = 2;
    do { checks++; if (n % i == 0) return 0; i++; } while (i * i <= n);
    return 1;
}

/* Overflow demo with 32-bit arithmetic */
static int prime_u32_unsafe(uint32_t n, unsigned long limit, int *hit_limit)
{
    unsigned long it = 0; *hit_limit = 0;
    for (uint32_t i = 2; i * i <= n; i++) { if (++it > limit) { *hit_limit = 1; return -1; } if (n % i == 0) return 0; }
    return 1;
}
static int prime_u32_safe(uint32_t n)
{
    for (uint32_t i = 2; i <= n / i; i++) if (n % i == 0) return 0;   /* no multiplication */
    return 1;
}

int main(void)
{
    unsigned long t[] = {2, 3, 4, 97, 100, 7919, 1000003, 999983, 1000001};
    int nt = sizeof t / sizeof t[0];
    printf("%-9s %-9s | %10s %10s %10s %10s\n", "n", "result", "i<n (for)", "sqrt for", "sqrt while", "sqrt do-wh");
    for (int k = 0; k < nt; k++) {
        unsigned long n = t[k];
        int r1 = prime_full_for(n);  unsigned long c1 = checks;
        int r2 = prime_sqrt_for(n);  unsigned long c2 = checks;
        int r3 = prime_sqrt_while(n);unsigned long c3 = checks;
        int r4 = prime_sqrt_dowhile(n); unsigned long c4 = checks;
        printf("%-9lu %-9s | %10lu %10lu %10lu %10lu %s\n", n, r2 ? "prime" : "not prime", c1, c2, c3, c4,
               (r1 == r2 && r2 == r3 && r3 == r4) ? "" : "<-- MISMATCH");
    }

    printf("\ndo-while without guard: n=2 -> %s, n=3 -> %s (wrong: 2%%2==0 on first pass)\n",
           prime_dowhile_naive(2) ? "prime" : "NOT prime", prime_dowhile_naive(3) ? "prime" : "NOT prime");
    printf("do-while with guard   : n=2 -> %s, n=3 -> %s\n",
           prime_sqrt_dowhile(2) ? "prime" : "NOT prime", prime_sqrt_dowhile(3) ? "prime" : "NOT prime");

    int hit;
    uint32_t big = 4294967291u; /* largest prime below 2^32 */
    int r = prime_u32_unsafe(big, 100000UL, &hit);
    printf("\nOverflow: uint32 n=%u, loop 'i*i <= n' : result=%d, stopped by safety limit=%s (i*i wraps to 0 at i=65536)\n",
           big, r, hit ? "YES" : "no");
    printf("          safe condition 'i <= n/i' : %s\n", prime_u32_safe(big) ? "prime (correct)" : "not prime");

    /* Sieve comparison on N = 1,000,003 */
    enum { N = 1000003 };
    unsigned char *flag = malloc(N + 1);
    memset(flag, 1, N + 1); flag[0] = flag[1] = 0;
    unsigned long marks = 0;
    clock_t c0 = clock();
    for (unsigned long i = 2; i * i <= N; i++)
        if (flag[i]) for (unsigned long j = i * i; j <= N; j += i) { flag[j] = 0; marks++; }
    clock_t c1 = clock();
    unsigned long np = 0; for (int i = 0; i <= N; i++) np += flag[i];
    printf("\nSieve up to %d: %lu marking operations, %lu primes, memory %d bytes, time %.2f ms\n",
           N, marks, np, N + 1, 1000.0 * (c1 - c0) / CLOCKS_PER_SEC);
    printf("Sieve lookups: 97->%d, 100->%d, 7919->%d, 1000003->%d (0 divisions each)\n", flag[97], flag[100], flag[7919], flag[1000003]);

    unsigned long total = 0;
    for (unsigned long n = 2; n <= N; n++) { prime_sqrt_for(n); total += checks; }
    printf("Trial division of ALL n in 2..%d: total divisions = %lu\n", N, total);
    free(flag);
    return 0;
}
