#!/bin/sh
# Run this ONE STEP AT A TIME, as you actually finish each question, so the commit
# history shows real progressive work. Replace <RegisterNumber> and the GitHub username.
#
# git init && git branch -M main
# git remote add origin https://github.com/<user>/CSA02-<RegisterNumber>-Assignment2.git
#
# git add Q1 && git commit -m "Q1: precedence/associativity analysis and corrected billing"
# git add Q2 && git commit -m "Q2: short-circuit experiments and call counts"
# git add Q3 && git commit -m "Q3: bitwise register functions, trace and signedness"
# git add Q4 && git commit -m "Q4: switch/ladder/table grade classifier and tests"
# git add Q5 && git commit -m "Q5: prime loop versions and division counts"
# git add Q6 && git commit -m "Q6: loan schedule, termination and growth study"
# git add Q7 && git commit -m "Q7: redesign (6k+-1 wheel, sieve) and validation"
# git add README.md report.md && git commit -m "Add README and report"
# git push -u origin main
