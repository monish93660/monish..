/* Q4: ladder vs switch vs lookup table, boundary tests, missing-break effect, scholarship rule */
#include <stdio.h>

static unsigned long cmp_ladder = 0;

static char grade_ladder(int m)
{
    cmp_ladder++; if (m < 0 || m > 100) return '?';
    cmp_ladder++; if (m >= 90) return 'S';
    cmp_ladder++; if (m >= 80) return 'A';
    cmp_ladder++; if (m >= 70) return 'B';
    cmp_ladder++; if (m >= 60) return 'C';
    cmp_ladder++; if (m >= 50) return 'D';
    return 'F';
}

static char grade_switch(int m)
{
    if (m < 0 || m > 100) return '?';
    switch (m / 10) {
    case 10: case 9: return 'S';
    case 8: return 'A';
    case 7: return 'B';
    case 6: return 'C';
    case 5: return 'D';
    default: return 'F';
    }
}

/* Same switch with the 'return' of case 8 removed (missing break) -> falls through */
static char grade_switch_nobreak(int m)
{
    char g = 'F';
    if (m < 0 || m > 100) return '?';
    switch (m / 10) {
    case 10: case 9: g = 'S'; break;
    case 8: g = 'A';            /* <-- break missing */
    case 7: g = 'B'; break;
    case 6: g = 'C'; break;
    case 5: g = 'D'; break;
    default: g = 'F';
    }
    return g;
}

static const char table[11] = {'F','F','F','F','F','D','C','B','A','S','S'};
static char grade_table(int m)
{
    if (m < 0 || m > 100) return '?';
    return table[m / 10];
}

/* Scholarship: grade x income band -> percentage, via lookup table */
static int income_band(int income)   /* 0: <2.5L, 1: 2.5-5L, 2: 5-8L, 3: >8L (rupees per year) */
{
    if (income < 250000) return 0;
    if (income < 500000) return 1;
    if (income < 800000) return 2;
    return 3;
}
static int grade_index(char g) { switch (g) { case 'S': return 0; case 'A': return 1; case 'B': return 2; case 'C': return 3; case 'D': return 4; default: return -1; } }
static const int scholarship[5][4] = {
    /* income band: 0    1    2   3 */
    /* S */ {100, 75, 50, 25},
    /* A */ { 75, 50, 25, 0},
    /* B */ { 50, 25, 0, 0},
    /* C */ { 25, 0, 0, 0},
    /* D */ {  0, 0, 0, 0}};
static int scholarship_pct(int marks, int income)
{
    char g = grade_table(marks);
    int gi = grade_index(g);
    return gi < 0 ? 0 : scholarship[gi][income_band(income)];
}

int main(void)
{
    int tests[] = {100, 90, 89, 80, 79, 70, 69, 60, 59, 50, 49, 0, -1, 101};
    int nt = sizeof tests / sizeof tests[0];
    printf("%-6s %-7s %-7s %-7s %-9s\n", "marks", "ladder", "switch", "table", "no-break");
    for (int i = 0; i < nt; i++) {
        int m = tests[i];
        printf("%-6d %-7c %-7c %-7c %-9c\n", m, grade_ladder(m), grade_switch(m), grade_table(m), grade_switch_nobreak(m));
    }

    int mism = 0, mism_nb = 0;
    cmp_ladder = 0;
    for (int m = -5; m <= 105; m++) {
        char a = grade_ladder(m), b = grade_switch(m), c = grade_table(m);
        if (a != b || a != c) mism++;
        if (a != grade_switch_nobreak(m)) mism_nb++;
    }
    printf("\nExhaustive -5..105 (111 values): ladder/switch/table mismatches = %d; no-break mismatches = %d\n", mism, mism_nb);

    unsigned long total = 0, n = 0;
    for (int m = 0; m <= 100; m++) { cmp_ladder = 0; grade_ladder(m); total += cmp_ladder; n++; }
    printf("Ladder comparisons for marks 0..100: total=%lu average=%.2f per grade (max 6)\n", total, (double)total / n);
    printf("Switch: 1 range check + 1 jump-table index; table: 1 range check + 1 index (O(1))\n");

    printf("\nScholarship rule (marks, income) -> %%\n");
    int sm[] = {95, 85, 75, 65, 55, 45}; int si[] = {200000, 400000, 600000, 900000};
    printf("marks \\ income  200000 400000 600000 900000\n");
    for (int i = 0; i < 6; i++) {
        printf("%-6d (%c)       ", sm[i], grade_table(sm[i]));
        for (int j = 0; j < 4; j++) printf("%-7d", scholarship_pct(sm[i], si[j]));
        printf("\n");
    }
    return 0;
}
