# CSA02-<RegisterNumber>-Assignment2

- **Student name:** `<YOUR NAME>`
- **Register number:** `<YOUR REGISTER NUMBER>`
- **Compiler:** gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0 (GCC 13)
- **Report:** `report.md` (all predictions, analysis, tables, counts)

## Compile command (exact)

```
gcc -Wall -Wextra -o <exe> <file>.c -lm
```
(`-lm` is only needed for Q6.)

## Steps to execute each program

| Q | Folder | Compile and run | Raw output file |
|---|--------|-----------------|-----------------|
| Q1 | `Q1/` | `gcc -Wall -Wextra -o q1 q1_billing.c && ./q1` | `output.txt`, `compile_warnings.txt` |
| Q2 | `Q2/` | `gcc -Wall -Wextra -o q2 q2_shortcircuit.c && ./q2` | `output.txt` |
| Q3 | `Q3/` | `gcc -Wall -Wextra -o q3 q3_complete.c && ./q3` (given program, TODO 1–4 filled)<br>`gcc -Wall -Wextra -o q3x q3_extra.c && ./q3x` (traces, signedness, array alternative) | `output_complete.txt`, `output_extra.txt` |
| Q4 | `Q4/` | `gcc -Wall -Wextra -o q4 q4_complete.c && ./q4` (TODO 1)<br>`gcc -Wall -Wextra -o q4c q4_compare.c && ./q4c` | `output_complete.txt`, `output_compare.txt` |
| Q5 | `Q5/` | `gcc -Wall -Wextra -o q5 q5_complete.c && ./q5` (TODO 1)<br>`gcc -Wall -Wextra -o q5v q5_versions.c && ./q5v` | `output_complete.txt`, `output_versions.txt` |
| Q6 | `Q6/` | `gcc -Wall -Wextra -o q6 q6_loan.c -lm && ./q6` | `output.txt` |
| Q7 | `Q7/` | `gcc -Wall -Wextra -o q7 q7_redesign.c && ./q7` | `output.txt` |

Screenshots: run each program in your terminal and save the screenshot as `Qn/screenshot_*.png`.

## Result of each question

- **Q1** – The original expression gives 900 / 267 / 1260 (net 900 / 267 / 1210) for the three test bills; the intended amounts are 892.50 / 265.0725 / 1260 (net 892.50 / 265.0725 / 1210). The errors are integer truncation and GST charged on the undiscounted amount. `count = count++ + 1` is undefined behaviour (`-Wsequence-point` warning). The corrected version uses intermediate variables and `double`.
- **Q2** – For 1000 passengers, cheap-first `(S&&E)||slow` and nested `if` made 875 slow calls; slow-first and the `&`/`|` version made 1000. With a mandatory audit log, short-circuiting skips 125 audit entries, so verification must be called unconditionally.
- **Q3** – All four bit functions completed; output is `00000101`, `00000110`, `AC is ON, PUMP is OFF`, matching the expected output. The register trace matched every prediction.
- **Q4** – The switch version output `100:S 95:S 83:A 50:D 49:F -5:?`, matching. The ladder, switch and lookup table agree on all of -5..105. Removing one `return` made the 80–89 marks come out as B (10 mismatches).
- **Q5** – Output matches the expected 8 / 1 / 87 / 999 divisions. With `i < n` the counts are 95 / 1 / 7917 / 1000001. The `for`, `while` and `do-while` versions give identical counts.
- **Q6** – The Rs 10,000 loan at 2% with Rs 2,000 repayments clears in 6 months with total interest Rs 645.38, which matches the hand calculation. A 360-month limit and a repayment-≤-interest check prevent endless loops.
- **Q7** – Redesign of Q5. The 6k±1 loop cut divisions by 65.0% over all tickets (67,741,504 → 23,739,568); the sieve needs 0 divisions per query at the cost of 1 MB of memory.
