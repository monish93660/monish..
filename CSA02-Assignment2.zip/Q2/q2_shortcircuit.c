/* Q2 - Short-circuit evaluation: railway concession */
#include <stdio.h>

#define N 1000

static unsigned long slow_calls = 0;     /* calls to slow verification function */
static unsigned long audit_log_len = 0;  /* entries in audit log (changed condition) */
static int audit_enabled = 0;

static int slow_verify(int disability_card)
{
    slow_calls++;
    if (audit_enabled) audit_log_len++;
    return disability_card;
}

static int cheap_calls = 0;
static int cheap(int v) { cheap_calls++; return v; }

static unsigned int seed = 12345;
static int rnd(void) { seed = seed * 1103515245u + 12345u; return (int)((seed >> 16) & 0x7fff); }

static int senior[N], eligible[N], disab[N];

typedef int (*rule_fn)(int i);

/* A: cheap condition first, slow last */
static int rule_A(int i) { return (senior[i] && eligible[i]) || slow_verify(disab[i]); }
/* B: slow first */
static int rule_B(int i) { return slow_verify(disab[i]) || (senior[i] && eligible[i]); }
/* C: non-short-circuit operators: everything always evaluated */
static int rule_C(int i) { return (senior[i] & eligible[i]) | slow_verify(disab[i]); }
/* D: nested ifs (same behaviour as A) */
static int rule_D(int i)
{
    if (senior[i]) { if (eligible[i]) return 1; }
    if (slow_verify(disab[i])) return 1;
    return 0;
}

static void run(const char *name, rule_fn f)
{
    unsigned long granted = 0;
    slow_calls = 0; audit_log_len = 0;
    for (int i = 0; i < N; i++) granted += (unsigned long)f(i);
    printf("  %-28s slow calls = %4lu   audit entries = %4lu   concessions = %lu\n",
           name, slow_calls, audit_log_len, granted);
}

int main(void)
{
    /* ---- Part 1: when is the second operand not evaluated? ---- */
    printf("Part 1: operand evaluation\n");
    int r;
    cheap_calls = 0; r = cheap(0) && cheap(1);
    printf("  0 && f(): result=%d, f called %s (calls=%d)\n", r, cheap_calls == 2 ? "YES" : "NO", cheap_calls);
    cheap_calls = 0; r = cheap(1) && cheap(1);
    printf("  1 && f(): result=%d, f called %s (calls=%d)\n", r, cheap_calls == 2 ? "YES" : "NO", cheap_calls);
    cheap_calls = 0; r = cheap(1) || cheap(0);
    printf("  1 || f(): result=%d, f called %s (calls=%d)\n", r, cheap_calls == 2 ? "YES" : "NO", cheap_calls);
    cheap_calls = 0; r = cheap(0) || cheap(0);
    printf("  0 || f(): result=%d, f called %s (calls=%d)\n", r, cheap_calls == 2 ? "YES" : "NO", cheap_calls);
    cheap_calls = 0; r = cheap(0) & cheap(1);
    printf("  0 &  f(): result=%d, f called %s (calls=%d)  <- & always evaluates both\n", r, cheap_calls == 2 ? "YES" : "NO", cheap_calls);
    cheap_calls = 0; r = cheap(1) | cheap(0);
    printf("  1 |  f(): result=%d, f called %s (calls=%d)  <- | always evaluates both\n", r, cheap_calls == 2 ? "YES" : "NO", cheap_calls);

    int x = 0; r = (0 && x++); printf("  (0 && x++): x stays %d ; ", x);
    x = 0; r = (0 & x++); printf("(0 & x++): x becomes %d\n", x);
    (void)r;

    /* & versus && on non-boolean values */
    printf("  2 && 1 = %d, but 2 & 1 = %d (bitwise on non-0/1 values differs)\n", 2 && 1, 2 & 1);

    /* ---- Part 2: 1000 passengers ---- */
    int ns = 0, ne = 0, nd = 0;
    for (int i = 0; i < N; i++) {
        senior[i]   = rnd() % 100 < 30;   /* 30% seniors            */
        eligible[i] = rnd() % 100 < 40;   /* 40% eligible class     */
        disab[i]    = rnd() % 100 < 10;   /* 10% hold disability card */
        ns += senior[i]; ne += eligible[i]; nd += disab[i];
    }
    printf("\nPart 2: %d passengers (seniors=%d, eligible class=%d, disability=%d)\n", N, ns, ne, nd);
    audit_enabled = 0;
    printf("Without audit log:\n");
    run("A: (S&&E) || slow", rule_A);
    run("B: slow || (S&&E)", rule_B);
    run("C: (S&E) | slow", rule_C);
    run("D: nested if", rule_D);

    audit_enabled = 1;
    printf("With audit log (every passenger MUST be logged):\n");
    run("A: (S&&E) || slow", rule_A);
    run("B: slow || (S&&E)", rule_B);
    run("C: (S&E) | slow", rule_C);
    run("D: nested if", rule_D);
    return 0;
}
