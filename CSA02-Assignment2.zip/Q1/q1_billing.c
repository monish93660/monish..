/* Q1 - Precedence, associativity and the discount bug (Jan Aushadhi billing) */
#include <stdio.h>

/* Developer's original single expression (all int arithmetic). */
static void buggy(int price, int qty, int senior, int *total, int *net)
{
    *total = price * qty - price * qty * 15 / 100 * senior + price * qty * 5 / 100;
    *net = *total > 1000 ? *total - 50 : *total; /* Rs 50 off above Rs 1000 */
}

/* Corrected: intermediate variables, double arithmetic, GST on discounted amount. */
static void correct(double price, int qty, int senior, double *gross, double *discount,
                    double *taxable, double *gst, double *total, double *net)
{
    *gross    = price * qty;
    *discount = senior ? *gross * 0.15 : 0.0;
    *taxable  = *gross - *discount;
    *gst      = *taxable * 0.05;
    *total    = *taxable + *gst;
    *net      = (*total > 1000.0) ? *total - 50.0 : *total;
}

int main(void)
{
    struct { int price, qty, senior; } bills[] = {
        {250, 4, 1},   /* senior, gross 1000          */
        {99, 3, 1},    /* senior, odd amount (truncation) */
        {1200, 1, 0}   /* non-senior, above Rs 1000   */
    };

    printf("%-5s %-6s %-4s %-7s | %-10s %-8s | %-8s %-8s %-8s %-9s %-9s\n",
           "price", "qty", "sen", "", "buggy_tot", "buggy_net",
           "gross", "disc", "taxable", "total", "net");
    for (int i = 0; i < 3; i++) {
        int bt, bn;
        double g, d, t, gs, tot, n;
        buggy(bills[i].price, bills[i].qty, bills[i].senior, &bt, &bn);
        correct(bills[i].price, bills[i].qty, bills[i].senior, &g, &d, &t, &gs, &tot, &n);
        printf("%-5d %-6d %-4d %-7s | %-10d %-9d | %-8.2f %-8.2f %-8.2f %-9.4f %-9.4f\n",
               bills[i].price, bills[i].qty, bills[i].senior, "", bt, bn, g, d, t, tot, n);
    }

    /* Integer-division demonstration */
    printf("\nInteger division: 297*15/100 = %d (true 44.55), 297*5/100 = %d (true 14.85)\n",
           297 * 15 / 100, 297 * 5 / 100);
    printf("Order matters: 15/100*297 = %d (zero!), 297*15/100 = %d\n", 15 / 100 * 297, 297 * 15 / 100);

    /* Third statement: undefined behaviour (count modified twice, no sequence point) */
    int count = 5;
    count = count++ + 1;
    printf("\ncount = count++ + 1 with count=5 gave %d (undefined behaviour; compiler dependent)\n", count);
    return 0;
}
