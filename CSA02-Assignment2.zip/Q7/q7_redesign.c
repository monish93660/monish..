/* Q7 - Day-4 Design Challenge: redesign of Q5 prime checking.
   Original  : trial division by every i with i*i <= n         (O(sqrt n) per query)
   Redesign 1: skip multiples of 2 and 3 (6k +/- 1 wheel)      (about sqrt(n)/3 per query, no extra memory)
   Redesign 2: sieve once, answer each query by lookup         (O(N log log N) once, O(1) per query, O(N) memory) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

unsigned long checks = 0;

static int prime_orig(unsigned long n)
{
    checks = 0; if (n < 2) return 0;
    for (unsigned long i = 2; i * i <= n; i++) { checks++; if (n % i == 0) return 0; }
    return 1;
}

static int prime_wheel(unsigned long n)
{
    checks = 0;
    if (n < 2) return 0;
    if (n < 4) return 1;                         /* 2, 3 */
    checks++; if (n % 2 == 0) return 0;
    checks++; if (n % 3 == 0) return 0;
    for (unsigned long i = 5; i * i <= n; i += 6) {   /* i = 6k-1, i+2 = 6k+1 */
        checks++; if (n % i == 0) return 0;
        checks++; if (n % (i + 2) == 0) return 0;
    }
    return 1;
}

static unsigned char *flag; static unsigned long sieve_ops = 0;
static void build_sieve(unsigned long N)
{
    flag = malloc(N + 1); memset(flag, 1, N + 1); flag[0] = flag[1] = 0; sieve_ops = 0;
    for (unsigned long i = 2; i * i <= N; i++)
        if (flag[i]) for (unsigned long j = i * i; j <= N; j += i) { flag[j] = 0; sieve_ops++; }
}

int main(void)
{
    unsigned long tickets[] = {97, 100, 7919, 1000003, 999983, 1000001};
    int nt = sizeof tickets / sizeof tickets[0];

    printf("A. Same inputs, divisions per query\n");
    printf("%-9s %-9s %10s %10s %8s %10s\n", "n", "result", "original", "6k+-1", "saved", "sieve");
    for (int k = 0; k < nt; k++) {
        unsigned long n = tickets[k];
        int a = prime_orig(n); unsigned long ca = checks;
        int b = prime_wheel(n); unsigned long cb = checks;
        printf("%-9lu %-9s %10lu %10lu %7.1f%% %10d%s\n", n, a ? "prime" : "not prime", ca, cb,
               ca ? 100.0 * (double)(ca - cb) / ca : 0.0, 0, a == b ? "" : "  MISMATCH");
    }

    const unsigned long N = 1000003;
    clock_t s0 = clock(); build_sieve(N); clock_t s1 = clock();
    printf("\nB. Batch workload: verify EVERY ticket 1..%lu\n", N);
    unsigned long tot_o = 0, tot_w = 0, bad = 0, nprimes = 0;
    clock_t t0 = clock();
    for (unsigned long n = 1; n <= N; n++) { prime_orig(n); tot_o += checks; }
    clock_t t1 = clock();
    for (unsigned long n = 1; n <= N; n++) { int w = prime_wheel(n); tot_w += checks; if (w != flag[n]) bad++; nprimes += w; }
    clock_t t2 = clock();
    unsigned long hits = 0;
    clock_t t3 = clock();
    for (unsigned long n = 1; n <= N; n++) hits += flag[n];
    clock_t t4 = clock();
    printf("  %-22s divisions=%-10lu time=%7.1f ms  memory=0 bytes\n", "original (sqrt)", tot_o, 1000.0 * (t1 - t0) / CLOCKS_PER_SEC);
    printf("  %-22s divisions=%-10lu time=%7.1f ms  memory=0 bytes\n", "6k+-1 wheel", tot_w, 1000.0 * (t2 - t1) / CLOCKS_PER_SEC);
    printf("  %-22s divisions=0          marks=%lu build=%.1f ms + lookups %.1f ms memory=%lu bytes\n", "sieve", sieve_ops,
           1000.0 * (s1 - s0) / CLOCKS_PER_SEC, 1000.0 * (t4 - t3) / CLOCKS_PER_SEC, N + 1);
    printf("  Primes found: wheel=%lu sieve=%lu, disagreements between wheel and sieve = %lu\n", nprimes, hits, bad);
    printf("  Division reduction wheel vs original: %.1f%%\n", 100.0 * (double)(tot_o - tot_w) / tot_o);

    printf("\nC. Few queries (break-even): sieve cost %lu marks vs trial division per query\n", sieve_ops);
    unsigned long qs[] = {1, 10, 100, 1000, 10000};
    for (int i = 0; i < 5; i++) {
        unsigned long q = qs[i], tw = 0, to = 0;
        for (unsigned long j = 0; j < q; j++) { unsigned long n = N - j * 2; prime_orig(n); to += checks; prime_wheel(n); tw += checks; }
        printf("  %-6lu queries (large n near %lu): original=%-9lu wheel=%-9lu sieve=%lu marks\n", q, N, to, tw, sieve_ops);
    }
    free(flag);
    return 0;
}
