/* Q6 - Self-help-group micro-loan schedule, termination, growth, closed-form */
#include <stdio.h>
#include <math.h>

#define MAX_MONTHS 360
#define EPS 0.005   /* half a paisa */

/* Returns months taken, or -1 if loan never clears. Prints schedule when verbose. */
static int schedule(double principal, double rate, double pay, int verbose, double *total_interest)
{
    double balance = principal, interest_sum = 0.0;
    int month = 0;
    *total_interest = 0.0;

    if (pay <= principal * rate) {      /* repayment cannot even cover first month's interest */
        if (verbose) printf("  REJECTED: repayment %.2f <= first-month interest %.2f; balance would never fall.\n", pay, principal * rate);
        return -1;
    }
    if (verbose) printf("  %-5s %-10s %-10s %-10s %-10s\n", "Month", "Opening", "Interest", "Payment", "Closing");
    while (balance > EPS) {             /* while: number of months unknown in advance */
        if (month >= MAX_MONTHS) {      /* safety limit */
            if (verbose) printf("  STOPPED: reached %d months with balance %.2f still outstanding.\n", MAX_MONTHS, balance);
            *total_interest = interest_sum;
            return -1;
        }
        double opening = balance;
        double interest = balance * rate;
        balance += interest;
        double payment = (balance < pay) ? balance : pay;   /* last month pays only what remains */
        balance -= payment;
        interest_sum += interest;
        month++;
        if (verbose) printf("  %-5d %-10.2f %-10.2f %-10.2f %-10.2f\n", month, opening, interest, payment, balance < EPS ? 0.0 : balance);
    }
    *total_interest = interest_sum;
    return month;
}

int main(void)
{
    double ti;
    printf("Loan Rs 10000 at 2%% per month, repayment Rs 2000\n");
    int m = schedule(10000.0, 0.02, 2000.0, 1, &ti);
    printf("  Months = %d, total interest = %.4f, total paid = %.4f\n", m, ti, 10000.0 + ti);

    /* Closed form */
    double r = 0.02, P = 10000.0, E = 2000.0;
    double nf = -log(1.0 - r * P / E) / log(1.0 + r);
    printf("  Closed form n = %.4f -> ceil = %d months\n", nf, (int)ceil(nf));

    /* Why balance != 0 is dangerous */
    printf("\nDanger of 'balance != 0' with floating point (no last-month adjustment, limit 400):\n");
    double b = 10000.0; int k = 0;
    while (b != 0 && k < 400) { b = b * 1.02 - 2000.0; k++; if (b < 0) break; }
    printf("  After %d months balance = %.6f (never exactly 0; went negative = loan 'overpaid')\n", k, b);
    b = 0.1; k = 0; while (b != 1.0 && k < 20) { b += 0.1; k++; }
    printf("  Adding 0.1 repeatedly: reached 1.0 exactly? %s (after %d steps b=%.17g)\n", b == 1.0 ? "yes" : "NO", k, b);

    /* Growth investigation */
    printf("\nGrowth investigation (P=10000, r=2%%, monthly interest = 200):\n");
    printf("  %-10s %-8s %-12s %-12s %-10s\n", "repay", "months", "closed-form", "interest", "status");
    double pays[] = {5000, 3000, 2000, 1000, 500, 300, 250, 220, 210, 205, 201, 200.01, 200, 150};
    for (int i = 0; i < (int)(sizeof pays / sizeof pays[0]); i++) {
        int mm = schedule(10000.0, 0.02, pays[i], 0, &ti);
        double cf = (pays[i] > 200.0) ? -log(1.0 - 0.02 * 10000.0 / pays[i]) / log(1.02) : -1;
        if (mm > 0) printf("  %-10.2f %-8d %-12.2f %-12.2f ok\n", pays[i], mm, cf, ti);
        else if (pays[i] <= 200.0) printf("  %-10.2f %-8s %-12s %-12s rejected (repay <= interest)\n", pays[i], "-", "-", "-");
        else printf("  %-10.2f %-8s %-12.2f %-12.2f hit %d-month limit\n", pays[i], ">360", cf, ti, MAX_MONTHS);
    }

    /* Deployment decision: limit message */
    printf("\nSafety limit demo (repay Rs 200.01):\n");
    schedule(10000.0, 0.02, 200.01, 0, &ti);
    m = schedule(10000.0, 0.02, 200.01, 0, &ti);
    if (m < 0) printf("  Message: loan not repayable within %d months at this instalment; increase repayment.\n", MAX_MONTHS);
    printf("Rejected case (repay Rs 150):\n");
    schedule(10000.0, 0.02, 150.0, 1, &ti);
    return 0;
}
